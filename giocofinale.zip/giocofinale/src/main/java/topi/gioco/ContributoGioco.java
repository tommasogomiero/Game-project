package topi.gioco;

public class ContributoGioco {
	/* Costruttore */
	
	public ContributoGioco() {
	}
}