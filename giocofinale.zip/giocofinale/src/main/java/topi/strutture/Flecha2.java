package topi.strutture;

public class Flecha2 extends PannelloBase{
	/* Costanti */
	private final static String IMAGE_FLECHA = "immagini/flecha2.png";

	public Flecha2(int x, int y) {
		super(x,y);
	}
	
	/* Getters */
	public String getImage() {
		return IMAGE_FLECHA;
	}
}
