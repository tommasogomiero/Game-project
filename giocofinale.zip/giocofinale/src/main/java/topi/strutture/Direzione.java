package topi.strutture;

public enum Direzione {
	SINISTRA, SOPRA, SOTTO, DESTRA;
}