package topi.strutture;

public enum Stato {
	SOLLEVATO, ABBATTUTO;
}